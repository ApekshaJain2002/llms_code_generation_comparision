const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
    name: { type: String, required: true },
    code: { type: String, required: true },
    cyclomaticComplexity: { type: Number, required: true },
    linesOfCode: { type: Number, required: true },
    timeComplexity: { type: String, required: true },
    spaceComplexity: { type: String, required: true }
});

const Question = mongoose.model('Question', questionSchema);
module.exports = Question;
