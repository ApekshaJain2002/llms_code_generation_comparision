const express = require('express');
const router = express.Router();
const Question = require('../models/Question');

// Route to render the main page
router.get('/', (req, res) => {
    res.render('ind');
});

// Route to fetch all questions for the dashboard
router.get('/dashboard', async (req, res) => {
    try {
        const questions = await Question.find();
        res.render('index', { questions: questions });
    } catch (err) {
        console.error('Error fetching questions:', err);
        res.status(500).send('Error fetching questions from the database');
    }
});

// Route to display details of a selected question
router.get('/question', async (req, res) => {
    try {
        const questionId = req.query.questionId;
        const question = await Question.findById(questionId);

        if (!question) {
            return res.status(404).send('Question not found');
        }

        res.render('partials/questionDetails', { question });
    } catch (err) {
        console.error('Error fetching question:', err);
        res.status(500).send('Error fetching question');
    }
});

module.exports = router;
