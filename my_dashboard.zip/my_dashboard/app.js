const express = require('express');
const mongoose = require('mongoose');
const app = express();
const indexRouter = require('./routes/index');

mongoose.connect('mongodb://localhost:27017/questionDB')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Failed to connect to MongoDB', err));

app.set('view engine', 'ejs');

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use('/', indexRouter);

app.listen(3000, () => {
  console.log('Server started on port 3000');
});
