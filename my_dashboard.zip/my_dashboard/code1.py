import streamlit as st
from dotenv import load_dotenv
import os
import re
import shutil
import tempfile
import subprocess
import google.generativeai as genai

# Load environment variables
load_dotenv()

# Configure Gemini API
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))


def generate_gemini_code(prompt_text, language):
    model = genai.GenerativeModel("gemini-pro")
    prompt = f"Generate {language} code for the following: {prompt_text}"
    response = model.generate_content(prompt)
    return response.text


def clean_generated_code(code, language):
    # Remove language-specific markers and unnecessary lines
    if language == "Python":
        cleaned_code = re.sub(
            r'"""python\n|"""', '', code)  # Remove """python at start and triple quotes at end
    elif language == "C++":
        cleaned_code = re.sub(
            r'"""cpp\n|"""', '', code)      # Remove """cpp at start and triple quotes at end
    else:
        cleaned_code = code  # If no markers, return as-is

    # Remove any leading/trailing whitespace
    cleaned_code = cleaned_code.strip()
    return cleaned_code


def calculate_python_complexity(code_string):
    # Use flake8 to get cyclomatic complexity for Python code
    try:
        flake8_path = shutil.which("flake8")
        if flake8_path is None:
            raise Exception(
                "flake8 is not installed or not found in PATH. Install it with 'pip install flake8'.")

        with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as temp_file:
            temp_file.write(code_string.encode())
            temp_file_path = temp_file.name

        result = subprocess.run(
            [flake8_path, '--max-complexity=0', temp_file_path],
            capture_output=True, text=True
        )

        if result.returncode == 0:
            complexity_result = "All functions have cyclomatic complexity below the threshold."
        else:
            complexity_result = result.stdout

    except Exception as e:
        complexity_result = f"Error: {e}"
    finally:
        if 'temp_file_path' in locals() and temp_file_path:
            os.remove(temp_file_path)

    return complexity_result


def analyze_cpp_code(cpp_code):
    # C++ cyclomatic complexity analysis
    lines = cpp_code.splitlines()
    loc = sum(1 for line in lines if line.strip())
    cyclomatic_complexity = 1
    patterns = [r'\bif\b', r'\bfor\b', r'\bwhile\b',
                r'\bcase\b', r'\bcatch\b', r'\b&&\b', r'\b\|\|\b']
    for line in lines:
        stripped_line = line.strip()
        for pattern in patterns:
            cyclomatic_complexity += len(re.findall(pattern, stripped_line))
    return {"Lines of Code (LOC)": loc, "Cyclomatic Complexity": cyclomatic_complexity}

# Streamlit app


def main():
    st.title("")

    # Language selection
    language = st.selectbox("Select Language", ["Python", "C++"])

    # Prompt input
    st.write("Enter a code-related prompt, and Gemini will generate the code.")
    prompt = st.text_area("Enter your code question prompt:", height=100)

    if st.button("Generate Code"):
        if prompt:
            st.write("Generating code... Please wait.")
            try:
                generated_code = generate_gemini_code(prompt, language)

                # Clean the generated code
                cleaned_code = clean_generated_code(generated_code, language)

                # Display cleaned code
                st.subheader("Generated Code:")
                st.code(cleaned_code, language="python" if language ==
                        "Python" else "cpp")

                # Analyze and display complexity results
                if language == "Python":
                    st.write("Analyzing Python code for cyclomatic complexity...")
                    analysis_result = calculate_python_complexity(cleaned_code)
                    st.write("Complexity Analysis Result:")
                    st.text(analysis_result)

                elif language == "C++":
                    st.write("Analyzing C++ code for cyclomatic complexity...")
                    cpp_analysis_result = analyze_cpp_code(cleaned_code)
                    st.write("Complexity Analysis Result:")
                    st.text(
                        f"Lines of Code (LOC): {cpp_analysis_result['Lines of Code (LOC)']}")
                    st.text(
                        f"Cyclomatic Complexity: {cpp_analysis_result['Cyclomatic Complexity']}")

            except Exception as e:
                st.write(f"Error: {e}")
        else:
            st.write("Please enter a prompt.")


if __name__ == "__main__":
    main()
